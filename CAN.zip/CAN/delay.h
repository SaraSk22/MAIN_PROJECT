#ifndef _DELAY_H_
#define _DELAY_H_
#include "types.h"

void delay_us(u32 dlyUS);
void delay_ms(u32 dlyMS);

#endif
