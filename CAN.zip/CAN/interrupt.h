//interrupt.h
void eint0_isr(void) __irq;
void eint3_isr(void) __irq;
void Init_ENT(void);
