//pin_connect_block.h
void cfgportpinFunc(u32 portNo,
					u32 pinNo,
					u32 pinFunc);
